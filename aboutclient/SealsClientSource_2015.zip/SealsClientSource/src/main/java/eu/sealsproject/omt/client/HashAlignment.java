package eu.sealsproject.omt.client;

import java.util.HashMap;
import java.util.Set;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

/**
 * A HashMap-based Alignment representation with enables virtually
 * instantaneous searching for mappings, and linear-time Alignment
 * evaluation.
 * 
 * @author Daniel Faria
 */

public class HashAlignment
{
	private HashMap<String,HashMap<String,Relation>> alignment;
	private int size;
	
	/**
	 * Constructs a new empty HashAlignment
	 */
	public HashAlignment()
	{
		alignment = new HashMap<String,HashMap<String,Relation>>();
		size = 0;
	}
	
	/**
	 * Constructs a HashAlignment from an (Alignment API) Alignment
	 * @param a: the Alignment from which to construct the HashAlignment
	 */
	public HashAlignment(Alignment a)
	{
		this();
		for(Cell c : a)
		{
			try
			{
				String uri1 = c.getObject1AsURI().toString();
				String uri2 = c.getObject2AsURI().toString();
				Relation r = Relation.parse(c.getRelation().getRelation());
				add(uri1,uri2,r);
			}
			catch(AlignmentException e)
			{
				System.err.println("Error reading alignment: " + e.getMessage());
			}        	
		}
	}
	
	/**
	 * Constructs a HashAlignment that is a copy of the given HashAlignment
	 * @param other: the HashAlignment to copy
	 */
	public HashAlignment(HashAlignment other)
	{
		this();
		for(String source : other.alignment.keySet())
			for(String target : other.alignment.get(source).keySet())
				add(source, target, other.alignment.get(source).get(target));
	}

	/**
	 * Adds a mapping to the HashAlignment if it is new (i.e., the HashAlignment
	 * doesn't contain the mapping or its reverse)
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param r: the mapping relation between the entities
	 */
	public void add(String uri1, String uri2, Relation r)
	{
		//If the mapping already exists in the HashAlignment, return
		if(this.contains(uri1, uri2, r))
			return;
		//Otherwise, if the classes are mapped with a different relation
		//we update the relation
		if(this.contains(uri1, uri2))
		{
			alignment.get(uri1).put(uri2, r);
			return;
		}
		//Otherwise, we can increment the size and add the mapping
		size++;
		if(!alignment.containsKey(uri1))
		{
			HashMap<String,Relation> map = new HashMap<String,Relation>();
			map.put(uri2, r);
			alignment.put(uri1, map);
		}
		else
			alignment.get(uri1).put(uri2, r);
	}
	
	/**
	 * Adds all mappings in the given HashAlignment to this
	 * @param other: the HashAlignment to add to this
	 */
	public void add(HashAlignment other)
	{
		for(String source : other.alignment.keySet())
			for(String target : other.alignment.get(source).keySet())
				add(source, target, other.alignment.get(source).get(target));
	}
	
	/**
	 * Checks if two entities are mapped in the HashAlignment
	 * regardless of relation or direction
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param r: the mapping relation between the entities
	 * @return whether uri1 and uri2 are mapped in the HashAlignment
	 */
	public boolean contains(String uri1, String uri2)
	{
		return  (alignment.containsKey(uri1) &&	alignment.get(uri1).containsKey(uri2)) ||
				(alignment.containsKey(uri2) &&	alignment.get(uri2).containsKey(uri1));
	}
	
	/**
	 * Checks if a given mapping is contained in the HashAlignment
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param r: the mapping relation between the entities
	 * @return whether the mapping is containing in the HashAlignment
	 */
	public boolean contains(String uri1, String uri2, Relation r)
	{
		return (alignment.containsKey(uri1) && alignment.get(uri1).containsKey(uri2) && alignment.get(uri1).get(uri2) == r) ||
				(alignment.containsKey(uri2) &&	alignment.get(uri2).containsKey(uri1) && alignment.get(uri2).get(uri1) == r.reverse());
	}
	
	/**
	 * @param other: the HashAlignment to evaluate with this
	 * @return the classification of the other HashAlignment using this as
	 * a reference: {True Positives, False Positives, False Negatives}
	 */
	public int[] evaluation(HashAlignment other)
	{
		//Evaluation matrix
		int[] eval = new int[3];
		//True Positives
		eval[0] = 0;
		//False Positives
		eval[1] = other.size();
		//False Negatives
		eval[2] = 0;
		//Iterate through this alignment
		for(String source : this.alignment.keySet())
		{
			for(String target : this.alignment.get(source).keySet())
			{
				Relation r = this.alignment.get(source).get(target);
				//If the relation is unknown, we ignore the mapping
				if(r == Relation.UNKNOWN)
				{
					//And if it is in the other HashAlignment we discount
					//it, so it doesn't count as a False Positive
					if(other.contains(source, target))
						eval[1]--;
					continue;
				}
				//Otherwise, if the mapping is in the other HashAlignment
				//it is a True Positive
				if(other.contains(source, target, r))
					eval[0]++;
				//If it isn't, it is a False Negative
				else
					eval[2]++;
			}
		}
		//The False Positives are simply given by the mappings in the other
		//HashAlignment (which we already counted) that aren't True Positives
		//or unknowns (which we already discounted)
		eval[1] -= eval[0];
		return eval;
	}

	
	/**
	 * @return the set of source ontology entity URIs in this alignment
	 */
	public Set<String> getSources()
	{
		return alignment.keySet();
	}
	
	/**
	 * @param source: the source ontology entity URI to retrieve
	 * @return the set of target ontology entity URIs aligned to
	 * the given entity in this alignment
	 */
	public Set<String> getTargets(String source)
	{
		if(alignment.containsKey(source))
			return alignment.get(source).keySet();
		return null;
	}
	
	/**
	 * @param source: the source ontology entity URI to retrieve
	 * @param target: the target ontology entity URI to retrieve
	 * @return the relation between the given entities
	 */
	public Relation getRelation(String source, String target)
	{
		if(alignment.containsKey(source) && alignment.get(source).containsKey(target))
			return alignment.get(source).get(target);
		return null;
	}
	
	/**
	 * Removes a mapping from the HashAlignment if it exists
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param r: the mapping relation between the entities
	 */
	public void remove(String uri1, String uri2, Relation r)
	{
		if(alignment.containsKey(uri1) && alignment.get(uri1).containsKey(uri2) && alignment.get(uri1).get(uri2) == r)
		{
			if(r != Relation.UNKNOWN)
				size--;
			alignment.get(uri1).remove(uri2);
			if(alignment.get(uri1).isEmpty())
				alignment.remove(uri1);
		}
		else if(alignment.containsKey(uri2) && alignment.get(uri2).containsKey(uri1) &&	alignment.get(uri2).get(uri1) == r.reverse())
		{
			if(r != Relation.UNKNOWN)
				size--;
			alignment.get(uri2).remove(uri1);
			if(alignment.get(uri2).isEmpty())
				alignment.remove(uri2);
		}
	}
	
	/**
	 * @return the size of the HashAlignment
	 */
	public int size()
	{
		return size;
	}
}
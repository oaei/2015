package eu.sealsproject.omt.client.interactive;

import eu.sealsproject.omt.client.HashAlignment;
import eu.sealsproject.omt.client.Relation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

/**
 * Simulates user interaction through the use of a reference alignment
 * with an optional error rate
 * @author Daniel Faria, Dominique Ritze
 */
public class Oracle
{	
	private static HashAlignment refAlign;
	private static double error = 0.0;
	private static boolean interactive = false;
	private static HashAlignment positive;
	private static HashAlignment negative;
	private static Vector<Long> timeIntervals;
	private static long previousTime;
	private static String outRawResultFolder;
	private static String testCaseId;
	private static File queryLog;
	private static File timeLog;
	private static File results;
	private static int[][] oracleClassMatrix;
	
	/**
	 * Checks whether a given mapping is true
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param rel: the mapping relation in String form ("=", ">", or "<")
	 * @return
	 */
	public static boolean check(String uri1, String uri2, String rel)
	{
		Relation r = Relation.parse(rel);
		return check(uri1,uri2,r);
	}
	
	/**
	 * Checks whether a given mapping is true
	 * @param uri1: the URI of the source ontology entity
	 * @param uri2: the URI of the target ontology entity
	 * @param rel: the mapping Relation
	 * @return
	 */
	public static boolean check(String uri1, String uri2, Relation rel)
	{
		//Check interactive
		if(!interactive)
			return false;
		//Record time since previous request
		long time = System.currentTimeMillis();
		if(previousTime != -1)
			timeIntervals.add(time - previousTime);
		previousTime = time;
		//If the query was already done, return the result
		if(positive.contains(uri1, uri2, rel))
			return true;
		if(negative.contains(uri1, uri2, rel))
			return false;
		//Otherwise, if the mapping between uri1 and uri2 is 'unknown' in the
		//reference alignment return true by default, but do not store it or
		//count it as a query (it will also not count in the evaluation)
		if(refAlign.contains(uri1, uri2, Relation.UNKNOWN))
			return true;
		//Check if the query is present in the reference alignment
		boolean classification = refAlign.contains(uri1,uri2,rel);
		//Reverse the classification with probability given by the error
		if(Math.random() < error)
			classification = !classification;
		//Store the request
		if(classification)
			positive.add(uri1, uri2, rel);
		else
			negative.add(uri1, uri2, rel);
		return classification;
	}

	/**
	 * Save the logs and statistics, then reset the task variables 
	 */
	public static void endTask()
	{
		if(outRawResultFolder != null && testCaseId != null)
		{
			//Save the query log and compile the classification matrix
			BufferedWriter writer;
			int[][] classMatrix = new int[2][2];
			try
			{
				writer = new BufferedWriter(new FileWriter(queryLog, true));
				writer.append(testCaseId + "\n");
				for(String source : positive.getSources())
				{
					for(String target : positive.getTargets(source))
					{
						Relation r = positive.getRelation(source,target);
						//True positives
						if(refAlign.contains(source, target, r))
						{
							writer.append(source + " " + r.toString() + " " + target + "\tTP\n");
							classMatrix[0][0]++;
							oracleClassMatrix[0][0]++;
						}
						//False positives
						else
						{
							writer.append(source + " " + r.toString() + " " + target + "\tFP\n");
							classMatrix[0][1]++;
							oracleClassMatrix[0][1]++;
						}
					}
				}
				for(String source : negative.getSources())
				{
					for(String target : negative.getTargets(source))
					{
						Relation r = negative.getRelation(source,target);
						//False negatives
						if(refAlign.contains(source, target, r))
						{
							writer.append(source + " " + r.toString() + " " + target + "\tFN\n");
							classMatrix[1][1]++;
							oracleClassMatrix[1][1]++;
						}
						//True negatives
						else
						{
							writer.append(source + " " + r.toString() + " " + target + "\tTN\n");
							classMatrix[1][0]++;
							oracleClassMatrix[1][0]++;
						}
					}
				}
				writer.flush();
				writer.close();
			}
			catch(IOException e)
			{
				System.err.println("Error writing query log file: " + e.getMessage());
				e.printStackTrace();
			}
			//Save the time interval log
			try
			{
				writer = new BufferedWriter(new FileWriter(timeLog, true));
				writer.append(testCaseId + "\n");
				for(Long interval : timeIntervals)
					writer.append(interval + "\n");
				writer.flush();
				writer.close();
			}
			catch(IOException e)
			{
				System.err.println("Error writing time interval log file: " + e.getMessage());
				e.printStackTrace();
			}
			//Save the statistics
			try
			{
				writer = new BufferedWriter(new FileWriter(results, true));
				int total = positive.size()+negative.size();
				double precision = Math.min(Math.round(classMatrix[0][0] * 1000.0 / positive.size())/1000.0, 1.0);
				double negPrecision = Math.min(Math.round(classMatrix[1][0] * 1000.0 / negative.size())/1000.0, 1.0);
				writer.append(testCaseId + "\t" + total + "\t" + classMatrix[0][0] + "\t" +
						classMatrix[1][0] + "\t" + classMatrix[0][1] + "\t" + classMatrix[1][1] +
						"\t" + precision + "\t" + negPrecision + "\n");
				writer.flush();
				writer.close();
			}
			catch(IOException e)
			{
				System.err.println("Error writing results file: " + e.getMessage());
				e.printStackTrace();
			}	

		}
		refAlign = null;
		testCaseId = null;
		timeIntervals = null;
		interactive = false;
	}
	
	public static void endSuite()
	{
		if(outRawResultFolder != null)
		{
			try
			{
				BufferedWriter writer = new BufferedWriter(new FileWriter(results, true));
				int total = positive.size()+negative.size();
				double precision = Math.min(Math.round(oracleClassMatrix[0][0] * 1000.0 / positive.size())/1000.0, 1.0);
				double negPrecision = Math.min(Math.round(oracleClassMatrix[1][0] * 1000.0 / negative.size())/1000.0, 1.0);
				writer.append("Global\t" + total + "\t" + oracleClassMatrix[0][0] + "\t" +
						oracleClassMatrix[1][0] + oracleClassMatrix[0][1] + "\t" + oracleClassMatrix[0][1] +
						"\t" + precision + "\t" + negPrecision + "\n");
				writer.flush();
				writer.close();
			}
			catch(IOException e)
			{
				System.err.println("Error writing results file: " + e.getMessage());
				e.printStackTrace();
			}
			outRawResultFolder = null;
		}
		oracleClassMatrix = null;
	}
	
	/**
	 * @return the reference alignment according to the Oracle
	 * (i.e., with false positives and negatives introduced
	 * according to the error rate).
	 */
	public static HashAlignment getOracleReference()
	{
		//Initiate as a copy of the true reference
		HashAlignment oracleAlign = new HashAlignment(refAlign);
		//Add false positives
		for(String source : positive.getSources())
			for(String target : positive.getTargets(source))
				if(!refAlign.contains(source, target, positive.getRelation(source,target)))
					oracleAlign.add(source, target, positive.getRelation(source,target));
		//Remove false negatives
		for(String source : negative.getSources())
			for(String target : negative.getTargets(source))
				if(refAlign.contains(source, target, negative.getRelation(source,target)))
					oracleAlign.remove(source, target, negative.getRelation(source,target));
		return oracleAlign;
	}
	
	/**
	 * @return whether the track interactive
	 */
	public static boolean isInteractive()
	{
		return interactive;
	}
	
	public static void startSuite(double e, String folder)
	{
		error = e;
		oracleClassMatrix = new int[2][2];
		outRawResultFolder = folder;
		if(outRawResultFolder != null)
		{
			File resultsFolder = new File(outRawResultFolder);
			resultsFolder.mkdir();
			queryLog = new File(resultsFolder, "interactive_query_log.txt");
			if(queryLog.exists())
				queryLog.delete();
			timeLog = new File(resultsFolder, "interactive_request_intervals.txt");
			if(timeLog.exists())
				timeLog.delete();
			results = new File(resultsFolder, "interactive_results.txt");
			if(results.exists())
				results.delete();
			try
			{
				BufferedWriter writer = new BufferedWriter(new FileWriter(results, true));
				writer.append("Test Case ID\tTotal Requests\tTrue Positives\tTrue Negatives\tFalse Positives\tFalse Negatives\tPrecision\tNegative Precision\n");
				writer.flush();
				writer.close();
			}
			catch(IOException e1)
			{
				System.err.println("Error writing results file: " + e1.getMessage());
				e1.printStackTrace();
			}
		}
	}

	public static void startTask(HashAlignment referenceAlignment, String id)
	{
		refAlign = referenceAlignment;
		testCaseId = id;
		interactive = true;
		previousTime = -1;
		timeIntervals = new Vector<Long>();
		positive = new HashAlignment();
		negative = new HashAlignment();
	}
}
/---------------------------------------------------------------------------------------\
|                                                                            		|
|                         AlignmentEvaluator.jar                             		|
|                                                                            		|
|    Evaluates an alignment file in OAEI format against an OAEI reference    		|
|                alignment and outputs the evaluation.                       		|
|   Ignores mappings with unknown ('?') mapping relation in the reference.   		|
|                                                                            		|
|                                 Usage:                                     		|
|     java -jar LargeBioAlignmentEvaluator.jar -a 'path_to_alignment_to_evaluate'	|
|                    -r 'path_to_reference_alignment'                        		|
|                                                                            		|
|                         Author: Daniel Faria                               		|
|                           Date: 24-07-2014                                 		|
|                                                                            		|
\---------------------------------------------------------------------------------------/
